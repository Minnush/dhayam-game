# Dhayam Game

A browser-based version of **Dhayam**, the traditional Tamil cowrie-shell race board game.

Developed by **Minnushaa** for ISWE406P – Agile Development Process and DevOps Lab.

## How to run
Open `index.html` in any modern browser. No installation needed.

## Rules (summary)
- Two players (or Player vs Computer), four tokens each.
- Throw four cowrie shells: number of mouth-up shells = moves; zero up = 8.
- A throw of **1 (Dhayam)** is required to bring a token out.
- Throws of 1, 4, 8 and capturing an opponent give an extra turn.
- ★ squares are safe from capture.
- After one lap, tokens enter the home lane; first player to bring all four tokens home wins.

## Versions
- **v1.0** – Initial playable release.
